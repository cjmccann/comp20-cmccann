
/**
 * Module dependencies.
 */

var express = require('express');
var routes = require('./routes');
var user = require('./routes/user');
var http = require('http');
var path = require('path');

var mongo = require('mongodb');

var app = express();

var mongoUri = process.env.MONGOLAB_URI || process.env.MONGOHQ_URL || 'mongodb://localhost/scores';

mongo.Db.connect(mongoUri, function (err, db) {
  db.collection('mapMarkers', function(er, collection) {
    collection.insert({'name': 'gym'}, {safe: true}, function(er,rs) {
    });
  });
});

// all environments
app.set('port', process.env.PORT || 3000);
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');
app.use(express.favicon());
app.use(express.logger('dev'));
app.use(express.json());
app.use(express.urlencoded());
app.use(express.methodOverride());
app.use(app.router);
app.use(express.static(path.join(__dirname, 'public')));

// development only
if ('development' == app.get('env')) {
  app.use(express.errorHandler());
}

function timeStamp() {
	//Create a date object with the current time
	var now = new Date();

	// Create an array with the current month, day and time
	var date = [ now.getMonth() + 1, now.getDate(), now.getFullYear() ];

	// Create an array with the current hour, minute and second
	var time = [ now.getHours(), now.getMinutes(), now.getSeconds() ];

	// Determine AM or PM suffix based on the hour
	var suffix = ( time[0] < 12 ) ? "AM" : "PM";

	// Convert hour from military time
	time[0] = ( time[0] < 12 ) ? time[0] : time[0] - 12;

 	// If hour is 0, set it to 12
 	time[0] = time[0] || 12;

	// If seconds and minutes are less than 10, add a zero
	for ( var i = 1; i < 3; i++ ) {
      		if ( time[i] < 10 ) {
      			time[i] = "0" + time[i];
      		}
      	}

                         // Return the formatted string
            return date.join("/") + " " + time.join(":") + " " + suffix;
}

app.all('*', function(req, res, next) {
	res.header("Access-Control-Allow-Origin", "*");
	res.header("Access-Control-Allow-Headers", "X-Requested-With");
	next();
});

//app.get('/', routes.index);
app.get('/', function(req, res) {
	res.render('index', {tite: '2048'})	
});

app.get('/users', user.list);

app.get('/scores.json', function (req, res) { 
	mongo.Db.connect(mongoUri, function (err, db) {
		db.collection("scores", function (er, collection) {
			if (req.query.username) {
				var results = collection.find( { username : req.query.username } ).sort( { score : -1 } );
				var resultsJSON = [];
				var cur;

				results.each(function(err, result) {
					if (result == null) {
						res.json(resultsJSON);
						db.close();
						return;
					}

					if(result.username != null) {
						cur = { "username":result.username, "score":result.score, 
							    "grid":result.grid, "created_at": result.created_at }
						resultsJSON.push(cur);	
					}
				});

			} else {
				res.send("[]");
			}
		})
	})
})

app.get('/highScores.json', function (req, res) {
	mongo.Db.connect(mongoUri, function (err, db) {
		db.collection("scores", function (er, collection) {
			var results = collection.find().sort( { score : -1 } );
			var resultsJSON = [];
			var cur;

			results.each(function (err, result) {
				if (result == null) {
					res.json(resultsJSON);
					db.close();
					return;
				}

				if (result.username != null) {
					cur = { "username":result.username, "score":result.score, "created_at": result.created_at };
					resultsJSON.push(cur);
				}
			});
		})
	})
})

app.post('/submit.json', function (req, res) { 
	mongo.Db.connect(mongoUri, function (err, db) {
		db.collection("scores", function (er, collection) {
			if (req.body.username && req.body.score && req.body.grid) {
				var score = parseInt(req.body.score);
				var name  = req.body.username;
				var grid  = req.body.grid;
				var now =  timeStamp();

				collection.insert( {"username": name, "score" : score, "grid" : grid, 
									created_at : now  }, function (err, r) {});
				res.send("response text");
			}
		})
	})
})

http.createServer(app).listen(app.get('port'), function(){
  console.log('Express server listening on port ' + app.get('port'));
});


