function getScores () {
	var highScores = document.getElementById("highScores");
	var li;
	var inner;

	$('#highScores').empty();

	$.get("highScores.json", function (data) {
		console.log(data);

		for (var i = 0; i < data.length; i++) {
			console.log(i)
			li = document.createElement("li");
			inner = "Name: <strong>" + data[i].username + "</strong>" + 
						"<br>&nbsp;&nbsp;&nbsp;Score:<strong> " + data[i].score + "</strong>" + 
						"<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Date: <strong>" + data[i].created_at + "</strong>"; 
			li.innerHTML = inner;
			highScores.appendChild(li);
		}
	});
}
